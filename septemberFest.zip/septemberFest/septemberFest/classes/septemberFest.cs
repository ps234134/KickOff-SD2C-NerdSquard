﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace septemberFest.classes
{
    internal class septemberFest
    {
        MySqlConnection _dbConnect = new MySqlConnection("Server=localhost;Database=septemberfest;Uid=root;Pwd=;");


        //public DataTable SelectIDkaart()
        //{
        //    try
        //    {
        //        if (_dbConnect.State == ConnectionState.Closed)
        //            _dbConnect.Open();
        //        String query = "SELECT COUNT(1) FROM loginpage WHERE usename=@usename AND password=@password";
        //        MySqlCommand sqlCmd = new MySqlCommand(query, _dbConnect);
        //        sqlCmd.CommandType = CommandType.Text;
        //        sqlCmd.Parameters.AddWithValue("@usename", tbKaartId.Text);
        //        sqlCmd.Parameters.AddWithValue("@password", tbPassword.Password);
        //        int count = Convert.ToInt32(sqlCmd.ExecuteScalar());
        //    }
        //    catch (Exception ex)
        //    {
                
        //    }
        //    finally
        //    {
        //        _dbConnect.Close();
        //    }

        //    DataTable result = new DataTable();
        //    try
        //    {
        //        _dbConnect.Open();
        //        MySqlCommand command = _dbConnect.CreateCommand();
        //        command.CommandText = "SELECT `IdKaart`FROM `kaartgegevens` WHERE 1;";
        //        MySqlDataReader reader = command.ExecuteReader();
        //        result.Load(reader);
        //    }
        //    catch (Exception)
        //    {

        //    }
        //    finally
        //    {
        //        _dbConnect.Close();
        //    }
        //    return result;
        //}


    }


}
