﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace septemberFest
{
    /// <summary>
    /// Interaction logic for saldo.xaml
    /// </summary>
    public partial class saldo : Window
    {
        public saldo()
        {
            InitializeComponent();
        }

        private void btBetalen_Click(object sender, RoutedEventArgs e)
        {
            Window window = new betalen();
            window.Show();
            this.Close();
        }

        private void saldoToevogen_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
