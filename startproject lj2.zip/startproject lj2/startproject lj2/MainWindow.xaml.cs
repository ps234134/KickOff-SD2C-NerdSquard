﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace startproject_lj2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window

    {
        class DrinkClass
        {
            public int Index { get; set; }
            public string Name { get; set; }
            public float Price { get; set; }
        }
        public double _totaalPrijs = 0;

        List<DrinkClass> Drinken = new List<DrinkClass>()
        {
            new DrinkClass() { Index = 0, Name = "Bier", Price = 2.50f},
            new DrinkClass() { Index = 1, Name = "BierGroot", Price = 3.00f},
            new DrinkClass() { Index = 2, Name = "Rose", Price = 3.50f},
            new DrinkClass() { Index = 3, Name = "Mix", Price = 2.50f},
            new DrinkClass() { Index = 4, Name = "Shots", Price = 5.00f},
            new DrinkClass() { Index = 5, Name = "Sterk", Price = 10.00f},
            new DrinkClass() { Index = 6, Name = "Wijn", Price = 5.00f},
            new DrinkClass() { Index = 7, Name = "Fris", Price = 2.50f},
            new DrinkClass() { Index = 8, Name = "Water", Price = 2.50f},
        };
        public MainWindow()
        {
            InitializeComponent();
        }

        //Grid Menu Item Handlers
        private void bierClick(object sender, RoutedEventArgs e)
        {
            //    double prijs = 2.50;
            //    string content = bier.Content.ToString();
        } 

        private void biergrootClick(object sender, RoutedEventArgs e)
        {
            //double prijs = 3.00;
            //string content = biergroot.Content.ToString();
        }

        private void roseClick(object sender, RoutedEventArgs e)
        {
            //double prijs = 3.50;
            //string content = rose.Content.ToString();
        }

        private void mixClick(object sender, RoutedEventArgs e)
        {
            //double prijs = 2.50;

            //string content = mix.Content.ToString();
        }

        private void shotsClick(object sender, RoutedEventArgs e)
        {
            //double prijs = 1.50;

            //string content = shots.Content.ToString();
        }

        private void sterkClick(object sender, RoutedEventArgs e)
        {
            //double prijs = 3.00;

            //string content = sterk.Content.ToString();
        }

        private void wijnClick(object sender, RoutedEventArgs e)
        {
            //double prijs = 8.00;

            //string content = wijn.Content.ToString();
        }

        private void frisClick(object sender, RoutedEventArgs e)
        {
            //double prijs = 7.50;

            //string content = fris.Content.ToString();
        }

        private void waterClick(object sender, RoutedEventArgs e)
        {
            //double prijs = 6.00;

            //string content = water.Content.ToString();
            //StackPanel _sp = new StackPanel();
            //listbox.Items.Add(_sp);

            //Label order = new Label();
            //{
            //    Name = "orderLabel";
            //    order.Content = content + " €" + prijs;
            //    order.Foreground = new SolidColorBrush(Colors.Blue);
            //    _sp.Children.Add(order);

            //    //add  remove button to stackpanel
            //    Button removeBtn = new Button();
            //    {
            //        Name = "removeButton";
            //        removeBtn.Content = " X ";
            //        removeBtn.Click += removeBtn_Click;
            //        _sp.Children.Add(removeBtn);
            //        _totaalPrijs = _totaalPrijs - prijs;
            //    };
            //    _totaalPrijs = _totaalPrijs + prijs;
            //};
        }

        //private void removeBtn_Click(object sender, RoutedEventArgs e)
        //{
        //    Button btn = (Button)sender;
        //    StackPanel parenStackpanel = (StackPanel)btn.Parent;
        //    // gets label from stackpanel and saves content of it
        //    Label lbl = (Label)parenStackpanel.Children[0];
        //    string order = lbl.Content.ToString();

        //    // gets index of string till 'Totaal: '
        //    int orderIndex = order.IndexOf("€ ");
        //    // makes a new substring "with the content after "Totaal:" and filter out the price trough the RegexFilter Function
        //    string removePriceString = order.Substring(orderIndex);
        //    removePriceString = RegexFilter(removePriceString);
        //    double removePrice = double.Parse(removePriceString);
        //    // removes deleted price from total price and updates it
        //    _totaalPrijs = _totaalPrijs - removePrice;
        //    TotaalPrijs.Text = "Totaal bedrag: " + FormatPrice(_totaalPrijs);

        //    // removes the stackpanel as LB item, correct stackpanel is recognised due it being the parent of the btn that is the Sender.
        //    listbox.Items.RemoveAt(listbox.Items.IndexOf(btn.Parent));
        //}

        //private string FormatPrice(double prijs)
        //{
        //    return prijs.ToString("€0.00");
        //}
        //private string RegexFilter(string text)
        //{
        //    text = Regex.Match(text, @"\d+[,]\d+").Value;
        //    return text;
        //}


        //Order Completion logic
        private void DeleteAll_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
